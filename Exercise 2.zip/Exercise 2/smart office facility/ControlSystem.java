public class ControlSystem {
    
    public void turnOnLights(String roomName) {
        System.out.println("Turning on lights in " + roomName);
    }
    
    public void turnOffLights(String roomName) {
        System.out.println("Turning off lights in " + roomName);
    }
    
    public void turnOnAC(String roomName) {
        System.out.println("Turning on AC in " + roomName);
    }
    
    public void turnOffAC(String roomName) {
        System.out.println("Turning off AC in " + roomName);
    }
}
